package com.citibank.main;

public class DefaultConstructor {
	private int x;
	public DefaultConstructor(int x) {
		System.out.println("In Default Constructor");
		System.out.println(x);
	}
}

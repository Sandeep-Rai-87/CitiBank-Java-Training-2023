package com.citibank.main;

public class HelloWorldMain {
	public static void main (String args[]) {
		System.out.println("Hello World !!");
		System.out.println("Welcome to JAVA");
		System.out.println("###############");
		System.out.println("CSIPL Pune" + 200);
	}
}

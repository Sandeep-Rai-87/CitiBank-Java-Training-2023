package com.citibank.main;

import com.citibank.main.domain.MyClass;

public class MyClassMain {
	int num4 = 10;
	static int num5 = 10;
	public static void main(String[] args) {
		System.out.println("Main Start");
		MyClass myClass;
		MyClass.num2 = 10;
		System.out.println("Main End");
//		MyClass myClass = new MyClass();
//		myClass.display();
//		System.out.println("-------------------");
//		MyClass myClass1 = new MyClass();
//		myClass1.display();
//		
//		myClass.num2 = 20;
//		myClass.num1 = 20;
//		System.out.println("================");
//		System.out.println(MyClass.num2);
////		System.out.println(MyClass.num1);
//		
//		System.out.println("#################");
//		int x = 10; 
////		System.out.println(num4); // not allowed as the variable is non static
//		System.out.println("num5");
		

	}

}

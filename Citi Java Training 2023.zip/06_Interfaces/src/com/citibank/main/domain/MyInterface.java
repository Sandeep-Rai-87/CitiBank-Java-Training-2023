package com.citibank.main.domain;

public interface MyInterface {
	String message = "Interfaces are good for your application";
	void show();

}
